library(testthat)
library(NPEL.Classification)

test_check('NPEL.Classification')
