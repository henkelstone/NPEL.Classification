# Automated testing of NPEL.Classification package
# Created by Jonathan Henkelman 16.Feb.2016

library(NPEL.Classification)
context("Package")
cat('\n')

test_examples('../../man')
# testthat::test_examples('./man')
